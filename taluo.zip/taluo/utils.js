/* ============================================
   Nyx Studio - 工具函数库
   ============================================ */

// ============ 颜色常量 ============
const colors = {
  bg: '#0a0a12',
  bgLight: '#12121f',
  bgCard: '#1a1a2e',
  bgHover: '#252540',
  primary: '#9d4edd',
  primaryLight: '#c77dff',
  accent: '#ffd700',
  accentDark: '#b8860b',
  success: '#10b981',
  warning: '#f59e0b',
  danger: '#ef4444',
  text: '#e2e8f0',
  textMuted: '#94a3b8',
  border: '#2d2d44',
  normalOrder: '#3b82f6',
  giftOrder: '#ec4899',
  monthlyOrder: '#10b981',
  prepaidOrder: '#f59e0b',
  bonus: '#ffd700'
};

// ============ 初始数据 ============
const initialReceptionists = [
  {
    id: 1,
    name: '管理者',
    emoji: '🐯',
    role: 'manager',
    password: '123',
    balance: 0,
    isIntern: false,
    commissionRate: 5,
    commissionExpiry: null,
    penalties: [],
    isDeleted: false
  }
];

// ============ 日期工具函数 ============
function formatDate(date) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function getToday() {
  return formatDate(new Date());
}

function getWeekStart(date = new Date()) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  const start = new Date(d.setDate(diff));
  start.setHours(0, 0, 0, 0);
  return start;
}

function getMonthStart(date = new Date()) {
  return new Date(date.getFullYear(), date.getMonth(), 1);
}

function getDaysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
}

// ============ 订单类型工具函数 ============
function getOrderTypeColor(type) {
  switch (type) {
    case 'normal': return colors.normalOrder;
    case 'gift': return colors.giftOrder;
    case 'monthly': return colors.monthlyOrder;
    case 'prepaid': return colors.prepaidOrder;
    case 'deduct_prepaid': return colors.deductPrepaidOrder;
    case 'bonus': return colors.bonus;
    default: return colors.primary;
  }
}

function getOrderTypeName(type) {
  switch (type) {
    case 'normal': return '正常单';
    case 'gift': return '礼物单';
    case 'monthly': return '月卡单';
    case 'prepaid': return '预存单';
    case 'deduct_prepaid': return '扣除存单';
    case 'bonus': return '奖金';
    default: return type;
  }
}

function getOrderTypeBgColor(type) {
  const color = getOrderTypeColor(type);
  return `${color}15`;
}

// ============ 提成计算函数 ============
function calculateCommission(order, receptionist) {
  if (order.type === 'monthly') return 0;
  if (order.type === 'deduct_prepaid') return 0; // Deduct prepaid has no commission
  if (order.type === 'bonus') return order.amount;
  const rate = receptionist.commissionExpiry && new Date(receptionist.commissionExpiry) > new Date()
    ? receptionist.commissionRate
    : (order.type === 'normal' ? 5 : order.type === 'gift' ? 10 : 5);
  return order.amount * (rate / 100);
}

// 计算工作室收入（新计费规则）
// 正常单：25%，礼物单：10%，月卡单：9.9，预存单：25%，奖金：0，扣除预存：0
function calculateStudioIncomeForOrder(order) {
  switch (order.type) {
    case 'normal': return order.amount * 0.25;
    case 'gift': return order.amount * 0.10;
    case 'monthly': return 9.9;
    case 'prepaid': return order.amount * 0.25;
    case 'deduct_prepaid': return 0;
    case 'bonus': return 0;
    default: return 0;
  }
}

// 计算工作室总收入（只计算已审核订单）
function calculateTotalStudioIncome(orders) {
  return orders.filter(o => o.approved !== false).reduce((sum, o) => sum + calculateStudioIncomeForOrder(o), 0);
}

// ============ 老板预存系统 ============
function getBossBalance(bossName) {
  const orders = DataStore.getOrders();
  // Filter for approved orders related to this boss
  const bossOrders = orders.filter(o => o.bossName === bossName && o.approved !== false);

  const totalPredpaid = bossOrders
    .filter(o => o.type === 'prepaid')
    .reduce((sum, o) => sum + (o.amount || 0), 0);

  const totalDeducted = bossOrders
    .filter(o => o.type === 'deduct_prepaid')
    .reduce((sum, o) => sum + (o.amount || 0), 0);

  return totalPredpaid - totalDeducted;
}

function getBossMonthlyConsumption(bossName) {
  const orders = DataStore.getOrders();
  const monthStart = getMonthStart();
  const bossOrders = orders.filter(o =>
    o.bossName === bossName &&
    o.approved !== false &&
    new Date(o.createdAt) >= monthStart // Use createdAt for consistency
  );

  // Consumption = Normal + Gift + Monthly + Deduct Prepaid (Since prepaid itself is just a top-up, spending it is the consumption)
  // Note: 'monthly' order price is 0 recorded in amount usually, but studio gets 9.9. For Boss consumption stats, if 'monthly' order amount is stored as 0, we might need a fixed value?
  // User request: "Record monthly accumulated consumption". 
  // For 'monthly' card usage, usually the customer bought a card previously. 
  // Let's assume consumption is just the `amount` field for normal contexts.
  // For `deduct_prepaid`, the amount IS the value consumed.

  return bossOrders.reduce((sum, o) => {
    if (o.type === 'bonus') return sum;
    if (o.type === 'prepaid') return sum; // Top-up is not consumption
    return sum + (o.amount || 0);
  }, 0);
}

// 检查是否是周日21点后
function isAfterSundayDeadline() {
  const now = new Date();
  const day = now.getDay();
  const hour = now.getHours();
  return day === 0 && hour >= 21;
}

// ============ 数据存储管理 ============
const DataStore = {
  // 获取接待员列表
  getReceptionists() {
    const saved = localStorage.getItem('nyx_receptionists');
    let data = saved ? JSON.parse(saved) : [];

    // 移除可能存在的旧管理者账号（防止重复）
    data = data.filter(r => r.role !== 'manager');

    // 始终添加管理者账号
    const managerAccount = {
      id: 1,
      name: '管理者',
      emoji: '🐯',
      role: 'manager',
      password: '123',
      balance: 0,
      isIntern: false,
      commissionRate: 5,
      commissionExpiry: null,
      penalties: [],
      isDeleted: false
    };

    return [managerAccount, ...data];
  },

  // 保存接待员列表
  saveReceptionists(receptionists) {
    // 不保存管理者账号
    const dataToSave = receptionists.filter(r => r.role !== 'manager');
    localStorage.setItem('nyx_receptionists', JSON.stringify(dataToSave));
  },

  // 获取订单列表
  getOrders() {
    const saved = localStorage.getItem('nyx_orders');
    return saved ? JSON.parse(saved) : [];
  },

  // 保存订单列表
  saveOrders(orders) {
    localStorage.setItem('nyx_orders', JSON.stringify(orders));
  },

  // 获取公告列表
  getAnnouncements() {
    const saved = localStorage.getItem('nyx_announcements');
    return saved ? JSON.parse(saved) : [];
  },

  // 保存公告列表
  saveAnnouncements(announcements) {
    localStorage.setItem('nyx_announcements', JSON.stringify(announcements));
  },

  // 获取当前用户
  getCurrentUser() {
    const saved = sessionStorage.getItem('nyx_current_user');
    return saved ? JSON.parse(saved) : null;
  },

  // 保存当前用户
  setCurrentUser(user) {
    if (user) {
      sessionStorage.setItem('nyx_current_user', JSON.stringify(user));
    } else {
      sessionStorage.removeItem('nyx_current_user');
    }
  },

  // 获取已读公告
  getReadAnnouncements(userId) {
    const saved = localStorage.getItem(`nyx_read_${userId}`);
    return saved ? JSON.parse(saved) : [];
  },

  // 标记公告已读
  markAnnouncementRead(userId, announcementId) {
    const read = this.getReadAnnouncements(userId);
    if (!read.includes(announcementId)) {
      read.push(announcementId);
      localStorage.setItem(`nyx_read_${userId}`, JSON.stringify(read));
    }
  },

  // 获取周结算已完成列表
  getSettledIds() {
    const saved = localStorage.getItem('nyx_weekly_settled');
    return saved ? JSON.parse(saved) : [];
  },

  // 保存周结算已完成列表
  saveSettledIds(ids) {
    localStorage.setItem('nyx_weekly_settled', JSON.stringify(ids));
  },

  // 获取周任务打勾状态
  getPromotionChecks(userId) {
    const saved = localStorage.getItem(`nyx_promo_${userId}`);
    return saved ? JSON.parse(saved) : [false, false, false, false];
  },

  // 保存周任务打勾状态
  savePromotionChecks(userId, checks) {
    localStorage.setItem(`nyx_promo_${userId}`, JSON.stringify(checks));
  }
};

// ============ 计算接待余额 ============
function calculateBalance(receptionistId) {
  const orders = DataStore.getOrders();
  const receptionists = DataStore.getReceptionists();
  const receptionist = receptionists.find(r => r.id === receptionistId);

  if (!receptionist) {
    return { amount: 0, taskFailed: false };
  }

  // 获取上次结算时间
  const lastSettlementTime = receptionist.lastSettlementDate ? new Date(receptionist.lastSettlementDate).getTime() : 0;

  // 只计算已审核通过且在上次结算之后的订单
  const userOrders = orders.filter(o =>
    o.receptionistId === receptionistId &&
    o.approved !== false &&
    new Date(o.createdAt).getTime() > lastSettlementTime
  );

  let balance = 0;
  userOrders.forEach(order => {
    if (order.type === 'bonus') {
      balance += order.amount;
    } else if (order.type !== 'monthly') {
      balance += calculateCommission(order, receptionist);
    }
  });

  // 减去惩罚（只计算结算后的）
  const penalties = receptionist.penalties || [];
  penalties.forEach(p => {
    // 优先使用 createdAt，如果没有则使用 date
    const penaltyTime = p.createdAt ? new Date(p.createdAt).getTime() : new Date(p.date).getTime();
    if (penaltyTime > lastSettlementTime) {
      balance -= p.amount;
    }
  });

  // 检查周任务完成情况（只计算已审核且在结算后的订单）
  // 现在的逻辑是：如果结算了，任务也重置，所以直接用 userOrders 统计即可
  // 但要注意：周任务是基于"周"维度的。如果我在周三结算，那周一二的单子就不算了吗？
  // 用户说："周任务重新开始"。这意味着结算后，之前的单子不再计入当前的任务进度。
  // 所以从"现在"（结算后）开始重新累计。

  // 获取本周开始时间
  const weekStart = getWeekStart().getTime();
  // 任务统计的起始时间取：本周开始时间 和 上次结算时间 的较大值
  // 这样如果本周内结算过，就从结算后开始算；如果很久没结算，就从本周一开始算。
  const taskStartTime = Math.max(weekStart, lastSettlementTime);

  const weekOrders = userOrders.filter(o => {
    const orderTime = new Date(o.createdAt).getTime();
    return orderTime >= taskStartTime && o.type === 'monthly';
  });

  const taskCompleted = weekOrders.length >= 3;

  // 只有在周日21点后且未完成任务才清零
  if (isAfterSundayDeadline() && !taskCompleted) {
    return { amount: 0, taskFailed: true };
  }

  // 任务完成时加上底薪
  if (taskCompleted) {
    const baseSalary = receptionist.isIntern ? 20 : 40;
    balance += baseSalary;
  }

  return { amount: Math.round(balance * 100) / 100, taskFailed: false };
}

// ============ 登录/注册处理 ============
function handleLogin(username, password) {
  const receptionists = DataStore.getReceptionists();

  // 标准化用户名（去除空格和特殊字符）
  const normalizedUsername = username.trim();

  // 强制性管理者登录检查 - 支持多种写法
  const isManager = normalizedUsername === '管理者' ||
    normalizedUsername === '管理员' ||
    normalizedUsername.toLowerCase() === 'manager' ||
    normalizedUsername.toLowerCase() === 'admin';

  if (isManager && password === '123') {
    const managerUser = {
      id: 1,
      name: '管理者',
      emoji: '🐯',
      role: 'manager',
      password: '123',
      balance: 0,
      isIntern: false,
      commissionRate: 5,
      commissionExpiry: null,
      penalties: [],
      isDeleted: false
    };
    DataStore.setCurrentUser(managerUser);
    return { success: true, user: managerUser };
  }

  // 普通用户登录
  const user = receptionists.find(r => r.name === normalizedUsername && (r.role === 'manager' || !r.isDeleted));
  if (!user) {
    return { success: false, message: '未注册名字，请先注册哦宝宝。' };
  }
  if (user.password !== password) {
    return { success: false, message: '密码不正确宝宝qnq 请重新输入。\n忘记密码请联系运营。' };
  }
  DataStore.setCurrentUser(user);
  return { success: true, user };
}

function handleRegister(name, emoji, password) {
  const receptionists = DataStore.getReceptionists();

  if (receptionists.find(r => r.name === name)) {
    return { success: false, message: '该名称已被注册哦～' };
  }

  const newUser = {
    id: Date.now(),
    name,
    emoji,
    role: 'receptionist',
    password,
    balance: 0,
    isIntern: true,
    commissionRate: 5,
    commissionExpiry: null,
    penalties: []
  };

  receptionists.push(newUser);
  DataStore.saveReceptionists(receptionists);
  DataStore.setCurrentUser(newUser);

  return { success: true, user: newUser };
}

// ============ 订单处理 ============
function submitOrder(orderData) {
  const user = DataStore.getCurrentUser();
  const orders = DataStore.getOrders();

  const newOrder = {
    id: Date.now(),
    ...orderData,
    receptionistId: user.id,
    createdAt: new Date().toISOString(),
    approved: false // 新订单默认未审核
  };

  orders.push(newOrder);
  DataStore.saveOrders(orders);

  return { success: true, order: newOrder };
}

// ============ 星星背景生成 ============
function createStars(container) {
  const fragment = document.createDocumentFragment();

  for (let i = 0; i < 50; i++) {
    const star = document.createElement('div');
    star.className = 'star';
    star.style.left = `${Math.random() * 100}%`;
    star.style.top = `${Math.random() * 100}%`;
    star.style.width = `${Math.random() * 3 + 1}px`;
    star.style.height = star.style.width;
    star.style.animation = `twinkle ${Math.random() * 2 + 2}s ease-in-out ${Math.random() * 3}s infinite`;
    fragment.appendChild(star);
  }

  container.appendChild(fragment);
}

// ============ 删除小猫按钮 SVG ============
function createDeleteCatSVG() {
  return `
    <svg width="32" height="32" viewBox="0 0 100 100" style="pointer-events: none;">
      <!-- 猫头 -->
      <ellipse cx="50" cy="55" rx="30" ry="25" fill="#ffb6c1" stroke="#333" stroke-width="2"/>
      <!-- 左耳 -->
      <polygon points="25,35 15,10 40,30" fill="#ffb6c1" stroke="#333" stroke-width="2"/>
      <polygon points="28,32 22,18 36,30" fill="#ffc0cb"/>
      <!-- 右耳 -->
      <polygon points="75,35 85,10 60,30" fill="#ffb6c1" stroke="#333" stroke-width="2"/>
      <polygon points="72,32 78,18 64,30" fill="#ffc0cb"/>
      <!-- 左眼 - X形状 -->
      <line x1="32" y1="45" x2="42" y2="55" stroke="#333" stroke-width="3" stroke-linecap="round"/>
      <line x1="42" y1="45" x2="32" y2="55" stroke="#333" stroke-width="3" stroke-linecap="round"/>
      <!-- 右眼 - X形状 -->
      <line x1="58" y1="45" x2="68" y2="55" stroke="#333" stroke-width="3" stroke-linecap="round"/>
      <line x1="68" y1="45" x2="58" y2="55" stroke="#333" stroke-width="3" stroke-linecap="round"/>
      <!-- 鼻子 -->
      <ellipse cx="50" cy="62" rx="4" ry="3" fill="#ff69b4"/>
      <!-- 嘴巴 - 微笑 -->
      <path d="M 42 68 Q 50 75 58 68" fill="none" stroke="#333" stroke-width="2" stroke-linecap="round"/>
      <!-- 胡须 -->
      <line x1="20" y1="58" x2="35" y2="60" stroke="#333" stroke-width="1.5"/>
      <line x1="20" y1="65" x2="35" y2="65" stroke="#333" stroke-width="1.5"/>
      <line x1="65" y1="60" x2="80" y2="58" stroke="#333" stroke-width="1.5"/>
      <line x1="65" y1="65" x2="80" y2="65" stroke="#333" stroke-width="1.5"/>
    </svg>
  `;
}

// ============ Emoji 数据 ============
const emojiCategories = {
  '😊 表情': ['😀', '😃', '😄', '😁', '😆', '😅', '🤣', '😂', '🙂', '🙃', '😉', '😊', '😇', '🥰', '😍', '🤩', '😘', '😗', '😚', '😙', '🥲', '😋', '😛', '😜', '🤪', '😝', '🤑', '🤗', '🤭', '🤫', '🤔', '🤐', '🤨', '😐', '😑', '😶', '😏', '😒', '🙄', '😬'],
  '🌸 自然': ['🌸', '🌺', '🌻', '🌼', '🌷', '🌹', '🥀', '💐', '🌾', '🌿', '☘️', '🍀', '🍁', '🍂', '🍃', '🌵', '🌴', '🌳', '🌲', '🎋', '🎍', '🌱', '🪴', '🌏', '🌍', '🌎', '🌕', '🌙', '🌛', '🌜', '⭐', '🌟', '✨', '💫', '☀️', '🌈', '☁️', '❄️', '🔥', '💧'],
  '🦋 动物': ['🦋', '🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🐔', '🐧', '🐦', '🐤', '🦆', '🦅', '🦉', '🦇', '🐺', '🐗', '🐴', '🦄', '🐝', '🐛', '🐌', '🐞', '🐜', '🦗', '🐢', '🐍', '🦎', '🐙', '🦑', '🦐'],
  '🍎 食物': ['🍎', '🍐', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓', '🫐', '🍈', '🍒', '🍑', '🥭', '🍍', '🥥', '🥝', '🍅', '🍆', '🥑', '🥦', '🥬', '🥒', '🌶️', '🌽', '🥕', '🧄', '🧅', '🥔', '🍠', '🥐', '🥯', '🍞', '🥖', '🧀', '🥚', '🍳', '🥞', '🧇', '🍰', '🎂'],
  '🎮 活动': ['⚽', '🏀', '🏈', '⚾', '🎾', '🏐', '🎱', '🏓', '🏸', '🎯', '🎳', '🎮', '🎲', '🧩', '🎭', '🎨', '🎬', '🎤', '🎧', '🎷', '🎸', '🎹', '🥁', '🎺', '🎻', '🏆', '🥇', '🥈', '🥉', '🎖️', '🏅', '🎪', '🎟️', '🎫', '🎁', '🎀', '🎊', '🎉', '🎈', '🪅'],
  '💎 物品': ['💎', '💍', '👑', '👒', '🎩', '🧢', '👓', '🕶️', '🌂', '👜', '👛', '👝', '🎒', '💼', '📱', '💻', '⌨️', '🖥️', '📷', '📸', '📹', '🎥', '📺', '📻', '⏰', '🕰️', '⌛', '📡', '🔋', '💡', '🔦', '🕯️', '🔮', '🧿', '💌', '📦', '📫', '✏️', '📝', '📚'],
  '❤️ 符号': ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❤️‍🔥', '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '☮️', '✝️', '☪️', '🕉️', '☸️', '✡️', '🔯', '☯️', '♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓', '⛎']
};

// 正常单允许的金额列表
const allowedNormalAmounts = [119, 165, 198, 99, 98, 135, 388, 350, 310, 680, 190, 223, 253];

// 扣除存单允许的金额列表
const allowedDeductAmounts = [98, 99, 119, 135, 165, 190, 198, 223, 253, 310, 350, 388, 680];

// 检查老板是否存在（有过预存记录）
function isBossInSystem(bossName) {
  const orders = DataStore.getOrders();
  // 这里的定义是：只要系统里有过这个老板名字的 prepiad 订单，就算"在名单里"
  return orders.some(o => o.type === 'prepaid' && o.bossName === bossName);
}

// ============ 页面跳转 ============
function navigateTo(page) {
  window.location.href = page;
}

function logout() {
  DataStore.setCurrentUser(null);
  navigateTo('index.html');
}

// ============ 权限检查 ============
function requireLogin() {
  const user = DataStore.getCurrentUser();
  if (!user) {
    navigateTo('index.html');
    return null;
  }
  return user;
}

function requireManager() {
  const user = requireLogin();
  if (user && user.role !== 'manager') {
    navigateTo('receptionist.html');
    return null;
  }
  return user;
}

function requireReceptionist() {
  const user = requireLogin();
  if (user && user.role === 'manager') {
    navigateTo('manager.html');
    return null;
  }
  return user;
}

// ============ 初始化页面 ============
function initPage() {
  // 检查是否需要每周重置
  checkWeeklyReset();

  // 创建星星背景
  const starsContainer = document.querySelector('.stars-container');
  if (starsContainer) {
    createStars(starsContainer);
  }
}

// 检查每周一7点重置
function checkWeeklyReset() {
  const lastReset = localStorage.getItem('nyx_next_weekly_reset');
  const now = new Date();

  // 如果没有记录下次重置时间，则初始化为下一个周一 07:00
  if (!lastReset) {
    const nextMonday = getNextMonday7AM(now);
    localStorage.setItem('nyx_next_weekly_reset', nextMonday.toISOString());
    return;
  }

  const nextResetDate = new Date(lastReset);

  // 如果当前时间已经超过了设定的重置时间
  if (now >= nextResetDate) {
    console.log('触发每周重置：清空周结算清单');
    // 1. 清空结算清单（UI上的打勾）
    DataStore.saveSettledIds([]);

    // 2. 设定下一次重置时间（下个周一 07:00）
    // 注意：如果系统很久没打开，now 可能比 nextResetDate 大很多（例如过了两周）
    // 我们直接以当前时间为基准找下一个周一即可，或者简单地在 nextResetDate 基础上加一周直到大于 now
    // 简单做法：以 now 为基准找下一个周一，确保逻辑 "回到原本有的当周数据" 只是针对 UI 列表清空，
    // 不影响已经结算到用户身上的 lastSettlementDate。
    const nextMonday = getNextMonday7AM(now);
    localStorage.setItem('nyx_next_weekly_reset', nextMonday.toISOString());
  }
}

function getNextMonday7AM(date) {
  const d = new Date(date);
  const day = d.getDay(); // 0 是周日, 1 是周一...
  const diff = (day === 1 && d.getHours() < 7) ? 0 : (8 - (day === 0 ? 7 : day));

  // 如果是周一且还没到7点，diff是0，但我们应该设为"今天7点"
  // 如果是周一且过了7点，diff是7，设为"下周一7点"
  // 上面的 diff 逻辑算出来：
  // Mon(1) < 7点 -> 0 -> set hours 7 -> 今天7点
  // Mon(1) > 7点 -> 7 -> 下周一
  // Tue(2) -> 6 -> 下周一
  // Sun(0) -> 1 -> 下周一

  const target = new Date(d.getTime() + diff * 24 * 60 * 60 * 1000);
  target.setHours(7, 0, 0, 0);

  // 防御性检查：如果计算出的时间比当前时间小（例如今天周一8点，逻辑没处理好导致变成今天7点），加一周
  if (target <= date) {
    target.setDate(target.getDate() + 7);
  }

  return target;
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', initPage);
